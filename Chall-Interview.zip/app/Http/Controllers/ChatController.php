<?php

namespace App\Http\Controllers;

use App\Models\InterviewChallChat;
use App\Models\InterviewChallMsg;
use App\Models\InterviewChallUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ChatController extends Controller
{
    public function index(InterviewChallUser $chall)
    {       
        if(!$chall->Chat()->exists() && $chall->Expired)
        {
            session()->flash('error','زمان تحویل این چالش گذشته است');
            return back();
        }
        
        if(!$chall->Chat()->exists())
        $chat=DB::table('InterviewChallChatTbl')->insertGetId(['ChallUserId'=>$chall->Id,'Sender'=>auth()->user()->Id,'Resiver'=>auth()->user()->SupportId]);
        if(!$chall->Chat->Closed)
        DB::table('InterviewChallMsgTbl')
        ->where('ChatId',$chall->Chat->Id)
        ->where('Resiver',auth()->user()->Id)
        ->where('Seen',0)
        ->update(['Seen'=>1]);
        return view('panel.chat',compact('chall'));
    }
    public function send_message(Request $req)
    {
            if ($req->hasFile('file'))
             {
                $file=$req->file('file');
                    $fileName=$req->Resiver . '_'.$req->Sender.'_'.time() ."_FirsclassChallenge.{$file->extension()}"; 
                    if(!is_dir('uploads'))
                        mkdir('uploads');
                    if(!is_dir('uploads/Chat'))
                        mkdir('uploads/Chat');
                    if(!is_dir('uploads/Chat/'.$req->ChallId))
                     mkdir('uploads/Chat/'.$req->ChallId);
                    if(!is_dir('uploads/Chat/'.$req->ChallId.'/'.$req->ChatId))
                     mkdir('uploads/Chat/'.$req->ChallId.'/'.$req->ChatId);
                    $file->move(public_path().'/uploads/Chat/'.$req->ChallId.'/'.$req->ChatId.'/',$fileName);
                    $path=route('home').'/uploads/Chat/'.$req->ChallId.'/'.$req->ChatId.'/'.$fileName;
            }
            else
            $path='';
            $chatId=DB::table('InterviewChallMsgTbl')->insertGetId(['ChatId'=>$req->ChatId,'Sender'=>$req->Sender,'Resiver'=>$req->Resiver,'Body'=>$req->Body??null,'File'=>$path,"Seen"=>0]);
            $msg=InterviewChallMsg::find($chatId);    
            $logo=$msg->SenderUser->Logo??asset('dist/img/Logored.png');                    
            $EventController=new EventController();
            if(jdate($msg->Date)->format('Y-m-d')==jdate()->format('Y-m-d'))
            $date2="امروز";
            else
            $date2=jdate($msg->Date)->format('d F');
            $EventController->ChallengeChat($req->ChatId,$chatId,$msg->Resiver,$msg->Sender,$msg->Body??null,$path,$msg->SenderUser->FullName,$msg->ResiverUser->FullName,jdate($msg->Date)->format('Y-m-d H:i:s'),$date2,jdate($msg->Date)->format('H:i:s'),$logo);
            return response()->json(['success'=>1,'Body'=>$msg->Body,'File'=>$path,'Sender'=>$msg->SenderUser->FullName,'Logo'=>$logo,'Date'=>jdate($msg->Date)->format('Y-m-d H:i:s'),'Date2'=>$date2,"Time"=>jdate($msg->Date)->format('H:i:s'),'ResiverId'=>$msg->Resiver,'SenderId'=>$msg->Sender]);
    }
    public function read_chat(InterviewChallChat $chat,Request $req)
    {
        DB::table('InterviewChallMsgTbl')->where('ChatId',$chat->Id)
        ->where('Resiver',$req->Resiver)
        ->update(['Seen'=>1]);
        $EventController=new EventController();
        $EventController->ChallengeChatSeen($chat->Id,$chat->Resiver);
         return response()->json(['success'=>1]);
    }
    public function ajaxDetailes(Request $req)
    {       
        $chall=InterviewChallUser::find($req->Id);
       if($chall)
        $res=['success'=>1,'data'=>[
            'ChallLevel'=>$chall->Chall->Level,
            'Done'=>$chall->Done,
            'Expired'=>$chall->Expired,
            'ChallTitle'=>$chall->Chall->Title,
            'ChallBody'=>Str::limit($chall->Chall->Body, 55, '...'),
            'route'=>route('chall.details',[$chall->Id])
        ]];
        else
        $res=['success'=>0];
        return response()->json($res);
        
    }
}
