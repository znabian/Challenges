<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NotifController extends Controller
{   
    public function insert(Request $req)
    {
        $data=json_decode($req->get('data'));
        if($data->url=='chall')
        {
            $data->url=route("home");
        }
        else
        { 
            $data->url="/chat/".$data->ChatId;
        }
        DB::table('ReminderTbl')->insert([
            'UserId'=>$data->ResiverId,
            'Body'=>$data->Body,
            'Link'=>$data->url,
            'Seen'=>0,
            'Date'=>$data->Date,
        ]);
        return 1;
        
    }
}
