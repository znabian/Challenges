
<?php $__env->startSection('style'); ?>
    <style>
        #content
        {
            color: #fff;
            background-image: url("<?php echo e(asset('img/home/back.png')); ?>");
            background-attachment: fixed;
            background-size: contain;
            background-repeat: repeat-y;
            /* background-repeat: no-repeat; */
            background-position: center;
            height: 100vh;
            /* height: 88vh; */
            padding: 4vw;
        }
        .datechat
        {
          font-size: 9pt;
          text-align: center;
         color: #97b4f1;
        }
      
        .circle
            {
                width: 35px;
                height: 35px;
                border-radius: 50%;
                background-color: #3e427a;
                color: #fff;
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 15px;
                font-family: 'Vazir';

            }
     #msgtxt:focus
        {
            outline:none!important;
            border-color: #fff!important;
            box-shadow: unset!important;
        }
        #msgtxt::placeholder
        {
            color: #95a9b4;
            padding-top: 5px;

        }
        .line {
            border-top: 1px solid black;
            margin-top: 12px;
            margin-bottom: 20px;
        }
        .card-body {
            display: grid;
            grid-auto-rows: max-content;
            padding: 3%;
            grid-auto-columns: max-content;
            justify-content: center;
            height: 50rem;
            border:1px solid gray;
            overflow: auto;
            background-color: white;
        }

        .img-circle {
            width: 50%;
            max-width: 10%;
            height: 100%;
        }

        .sender
        {
          background-color: #7C80AB;
          /* border:2px solid #7C80AB; */
          color: #fff;
           float:right;
           border-radius:15px 0 15px 15px;
           margin: 5px;
           padding: 6px;
           font-size: 8pt;
        }
        .number
        {
           font-size: 6pt;          
        }
        .sendbox
        {
          margin-top: 11px;
          /* border-top: 1px solid; */
          padding: 10px;
          /* display: inline-flex; */
          justify-content: center;
        }
        .resiver p,.sender p
        {
          font-family: "Peyda";
        }
        .resiver
        {
          background-color: #7178c6;
          color: #fff;
           float:left;
           border-radius:0 15px 15px 15px;
           margin: 5px;
           padding: 6px;
           font-size: 8pt;
        }
        .chatcard
        {
          align-items: center;
          display: inline-flex;
          flex-direction: row-reverse;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h6 class="mb-3 text-center" style="font-size: 14pt"><?php echo e($chall->Chall->Title); ?></h6> 

  <div class="col-md-12 " id="chatBox" style="overflow: auto;height: 56vh;">
    <?php
        $chats=$chall->Chat->MSG()->orderBy('Date')->get();
        $pre=0;
    ?>
    <?php $__currentLoopData = $chats->groupBy(function($chats) {
      return date('Y-m-d',strtotime($chats->Date));
      }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(jdate($date)->format('Y-m-d')!=jdate()->format('Y-m-d')): ?>
     <h6 class="datechat" ><?php echo e(jdate($date)->format('d F')); ?></h6>
     <?php else: ?>
     <h6 class="datechat" >امروز</h6>
     <?php endif; ?>
     <?php
      if(jdate($date)->format('Y-m-d')!=jdate()->format('Y-m-d'))
         $dates[]=jdate($date)->format('d F');
         else
         $dates[]='امروز';
     ?>
      <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-12 d-flex <?php if(auth()->user()->Id!=$msg->Sender): ?> flex-row-reverse <?php endif; ?> " >
            
              <img src="<?php echo e(asset('img/user.png')); ?>" class="img-circle <?php if($pre==$msg->Sender): ?> opacity-0 <?php endif; ?>" alt="User Image">                          
            
            <div class=" <?php if(auth()->user()->Id==$msg->Sender): ?> sender <?php else: ?> resiver <?php endif; ?> col-md-6 col-6 row">            
              <div class="col-md-12 text-right" style="word-break: break-word;">
                <?php if($pre!=$msg->Sender): ?> 
                <b><?php echo e($msg->SenderUser->FullName); ?></b>
                <?php endif; ?>
                <?php if($msg->Body): ?>
                    <p><?php echo strtr($msg->Body,["\n"=>"<br>"]); ?></p>
                    <?php if($msg->File): ?>
                    <button onclick="window.open('<?php echo e($msg->File); ?>','_blank')" class="pull-left fa fa-download btn "> </button>
                    <?php endif; ?>
                <?php else: ?>
                <div class="d-flex gap-1" style="cursor: pointer;word-break: break-word;padding: 10px;" onclick="window.open('<?php echo e($msg->File); ?>','_blank')">
                  <i class=" fa fa-2x fa-file fa-regular"></i>
                  <b dir="ltr" style="font-size: 5pt;"><?php echo e(last(explode('/Chat/'.$chall->Id.'/'.$chall->Chat->Id.'/',$msg->File))); ?></b>                
                </div>
                <?php endif; ?>
              </div>
              <div class="<?php if(auth()->user()->Id==$msg->Sender): ?> p-0 text-right  <?php else: ?> text-left <?php endif; ?> ">
                <?php if(auth()->user()->Id==$msg->Sender): ?>
                <i class="fa  <?php if($msg->Seen): ?> fa-check-double px-1 text-3b407a <?php else: ?> fa-check <?php endif; ?> "></i>
                <?php endif; ?>
                <label class="fw-bolder number"><?php echo e(jdate($msg->Date)->format('H:i:s')); ?></label>
              </div>
            
            </div> 

        </div> 
        
        <?php
          $pre=$msg->Sender;
        ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$loop->last): ?>
          <?php
            $pre=0;
          ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
  </div> 
<?php if($chall->Chat->Closed): ?>
<div class="text-center " style="">
  <p class="alert bg-2F3068"><?php echo e(auth()->user()->FullName); ?> <br>  چت این چالش بسته شده </p>
</div>
<?php elseif($chall->Expired): ?>
<div class="text-center " style="">
  <p class="alert bg-2F3068"><?php echo e(auth()->user()->FullName); ?> <br> زمان تحویل این چالش گذشته </p>
</div>
<?php else: ?>
<div class="col-md-12 sendbox d-flex">
  <div class="d-flex " style="border-radius:  0px 25px 25px 0;background-color: #fff;">
  <button class="btn fa fa-paperclip" style="color:#f83673;border:none"  onclick="fileatt.click()"></button>
  </div>
  <textarea name="" id="msgtxt" rows="2" class="col-md-9 form-control" style="font-size: 9pt;border: none;border-radius: 0; resize: none;" placeholder="متن پیام"></textarea>
  <div class="d-flex flex-row-reverse" style="border-radius: 25px 0px 0 25px;background-color: #fff;">
    <button class="fa fa-paper-plane btn "  style="color:#f83673;border:none"  onclick="sendmsg(this)"></button>
    
    <input type="file" name="" id="fileatt" onchange="showprewview(this);" class="d-none" accept=".zip, .rar, .tar, .gz,.pdf">
  </div>
</div>


<?php endif; ?>

<dialog id="dialogFile" style="height: unset">
  <div class="d-flex">
    <h6 class="col-11">ارسال فایل</h6>
    <button class="btn btn-close " id="fileprev_del" onclick="fileatt.value='';dialogFile.close()"></button>
  </div>
  <div class="">
    <div class="bg-body-secondary d-flex p-2 p-md-4">
      <div class="m-auto d-grid">
        <span id="prevNAME" class=" small">219918-P1BLEW-593.png</span>        
         <span id="prevSIZE" class=" bold ltr number" style="font-size: 8pt">63.23 KB</span>
      </div>
    
      <div id="prevIMG" class="circle">
        <i class="fa fa-file fa-regular"></i>
      </div>
    </div>
    
  </div>
  <div class="box-footer mt-2">
    <textarea name="" id="msg2" rows="2" class="form-control" style="font-size: 9pt;border-radius: 10px;resize: none;" placeholder="متن پیام"></textarea>
    <button class="btn btn-primary mt-2 pull-left" onclick="sendmsg(this,1)">ارسال</button>
  </div>
</dialog>

<form action="" id="frm3"><?php echo csrf_field(); ?></form>
<audio src="<?php echo e(asset('sound/chat.mp3')); ?>" id="chataudio" style="display: none"></audio>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    chatBox.scrollTo( chatBox.scrollHeight, chatBox.scrollHeight); 
  var ChatId='<?php echo e($chall->Chat->Id); ?>';
  var uId='<?php echo e(auth()->user()->Id); ?>';
var dates=<?php echo json_encode($dates??[]); ?>;
<?php if(in_array(last($dates??[]),['امروز',jdate()->format('d F')])): ?>
var preSender=<?php echo e($pre); ?>;
<?php else: ?>
var preSender=0;
<?php endif; ?>
    
   
</script>
<script>

   function showprewview(obj)
    {
        var files=obj.files;
        if(files.length)
        {       
          var fileSize = files[0].size /1024/1024; 
          if (fileSize <= 100) 
          {
            document.getElementById('dialogFile').show();      
            document.getElementById('prevNAME').textContent=files[0].name; 
            var fileSizeInKB = files[0].size / 1024;
            var fileSizeInMB = fileSizeInKB / 1024;   
            if (fileSizeInMB < 1) 
            fileSize= fileSizeInKB.toFixed(2) + ' KB';
            else
            fileSize=fileSizeInMB.toFixed(2) + ' MB';
            document.getElementById('prevSIZE').textContent=fileSize;
            msg2.value=msgtxt.value;
          }
          else
          {
            document.getElementById('dialogFile').close();  
            obj.value='';fileSize = 0;
            Swal.fire({
                icon: 'error',
                title: 'توجه',                
                confirmButtonText: 'بله',
                text:"<?php echo e(auth()->user()->FullName); ?> \n فایل ارسالی بایستی کمتر از 100 مگ باشد"
            });
          }
        } 
        else
        document.getElementById('dialogFile').close();    
    }
    function sendmsg(obj,msgBox=0)
    {
      obj.disabled=true;
      var file=fileatt.files;
      if(msgBox)
      var msg=msg2.value;
      else
      var msg=msgtxt.value;
      msgtxt.value=msg2.value='';
      if(msg || file.length>0)
      {
        var upformData = new FormData(document.getElementById('frm3'));
        if(file.length)
        upformData.append('file', file[0]);
        if(msg)
        upformData.append('Body', msg);

        upformData.append('ChatId', '<?php echo e($chall->Chat->Id); ?>');
        upformData.append('ChallId', '<?php echo e($chall->Id); ?>');
        upformData.append('Resiver', '<?php echo e($chall->Chat->Resiver); ?>');
        upformData.append('Sender', '<?php echo e(auth()->user()->Id); ?>');
                    
        axios.post('<?php echo e(route("chat.send")); ?>', upformData, {
        headers: {
            'Content-Type': 'multipart/form-data'
        }
        })
        .then(response => { 
          preSender=uId;
           showmessages(response.data);
            obj.disabled=false;
          })
        .catch(error => {
            obj.disabled=false;
            console.log(error);
            obj.disabled=false;
            Swal.fire({
                        icon: 'error',
                        title: 'پیام ارسال نشد',                        
                        confirmButtonText: 'بله',
                        text:"<?php echo e(auth()->user()->FullName); ?> \n مشکلی پیش آمده مجدد تلاش کن"
                    });
         });
         
      }
      else
      {
        obj.disabled=false;msgtxt.focus();
      }
      
    }
   function showmessages(data)
   {
    if(!dates.includes(data.Date2))
    {
      var datechat=document.createElement("h6");
      datechat.textContent=data.Date2;
      datechat.classList.add("datechat");
      chatBox.appendChild(datechat);
      dates.push(data.Date2);
    }
    var div=document.createElement("div");
    div.className = "col-md-12 d-flex";
    if (uId == data.ResiverId)
     div.classList.add("flex-row-reverse");
    /*var innerDiv1 = document.createElement("div");
    innerDiv1.style.textAlign = "left";*/
    var img = document.createElement("img");
    img.src = "<?php echo e(asset('img/user.png')); ?>";
    img.className = "img-circle";

    if (preSender == data.SenderId)
      img.classList.add("opacity-0");

    //innerDiv1.appendChild(img);
    div.appendChild(img);
    var innerDiv2 = document.createElement("div");
    if (uId != data.ResiverId) 
      innerDiv2.className = "sender";
    else
      innerDiv2.className = "resiver";
    
    innerDiv2.classList.add("col-md-6","col-6","row");
    var innerDiv3 = document.createElement("div");
    innerDiv3.className = "col-md-12 text-right";
    innerDiv3.style.wordBreak = "break-word";
    if (preSender != data.SenderId)
     {
      var h6 = document.createElement("b");
      h6.textContent = data.Sender;
      innerDiv3.appendChild(h6);
    }
    if (data.Body) 
    {
      var p = document.createElement("p");
      p.innerHTML = data.Body.replace("\n","<br>");
      innerDiv3.appendChild(p);
      if (data.File) 
      {
        var button = document.createElement("button");
        button.className = "pull-left fa fa-download btn ";
        button.addEventListener("click",function() {
                    window.open(data.File,'_blank');
                  });
        innerDiv3.appendChild(button);
      }
    }
    else 
    {
      var div2 = document.createElement("div");
      div2.classList.add('d-flex','gap-1');
      div2.style.cursor = "pointer";
      div2.style.wordBreak = "break-word";
      div2.style.padding = "10px";
      div2.addEventListener("click",function() {
                    window.open(data.File,'_blank');
                  });
      var i = document.createElement("i");
      i.className = "fa fa-2x fa-file fa-regular";
      var b = document.createElement("b");
      b.dir = "ltr";
      b.style.fontSize= "5pt";
      b.textContent = data.File.split("<?php echo e('Chat/'.$chall->Id.'/'.$chall->Chat->Id.'/'); ?>")[1];
      div2.appendChild(i);
      div2.appendChild(b);
      innerDiv3.appendChild(div2);
    }
    innerDiv2.appendChild(innerDiv3);
    var innerDiv4 = document.createElement("div");
    if (uId != data.ResiverId)
      innerDiv4.className = "p-0 text-right";
    else
      innerDiv4.className = "text-left";
    
    if (uId != data.ResiverId) 
    {
      var ion = document.createElement("i");
      ion.className = "fa";
      if (data.Seen)
       {
        ion.classList.add("fa-check-double");
        ion.classList.add("px-1","text-3b407a");
      }
       else 
        ion.classList.add("fa-check");

      innerDiv4.appendChild(ion);
    }
    var label = document.createElement("label");
    label.className = "fw-bolder number";
    label.textContent = data.Time;
    innerDiv4.appendChild(label);
    innerDiv2.appendChild(innerDiv4);
    div.appendChild(innerDiv2);
    chatBox.appendChild(div);
    msgtxt.value='';
    fileprev_del.click();
    preSender=data.SenderId;
    chatBox.scrollTo( chatBox.scrollHeight, chatBox.scrollHeight);

   }
</script>
<?php if(!$chall->Chat->Closed): ?>

<script>
  const ably2 = new Ably.Realtime.Promise('<?php echo e(env('ABLY_KEY')); ?>');
    ably2.connection.once('connected');
  /* Rsive Message Channel*/
    var channel1 = ably2.channels.get('Challenge-Chat-Messages.'+ChatId+'_'+uId);
    channel1.subscribe('ChatMessages', function(data)
     {
      axios.post('<?php echo e(route("chat.read",[$chall->Chat->Id])); ?>',{Resiver:'<?php echo e(auth()->user()->Id); ?>'});      
        showmessages(JSON.parse(data.data));
        document.getElementById('chataudio').play();
                   
        
    });
    
    /*Seen Messages*/
    var channel2 = ably2.channels.get('Challenge-Chat-Seen.'+ChatId+'_'+uId);
    channel2.subscribe('ChatSeen', function(data) {          
      document.querySelectorAll('.fa-check').forEach(itm=>{
        itm.classList.remove('fa-check');
        itm.classList.add('fa-check-double','px-1','text-3b407a');
      }); 
    });

    /*Close Messages*/
    var channel3 = ably2.channels.get('Challenge-Chat-Close.'+ChatId+'_'+uId);
    channel3.subscribe('ChatClose', function(data) {          
      document.querySelectorAll('.sendbox').forEach(itm=>{
        itm.remove();
      }); 
      
      const div = document.createElement("div");
      div.classList.add("text-center");
      div.style = "";

      const p = document.createElement("p");
      p.classList.add("alert", "bg-2F3068");
      p.textContent = " چت این چالش بسته شده ";

      div.appendChild(p);
      content.appendChild(div);
    });
</script>
<?php endif; ?>
<script>
    const elements = document.querySelectorAll('.sender');
    elements.forEach(element => {

      element.addEventListener("contextmenu", function(event) {
        /*event.preventDefault();
        if(document.getElementById("contextMenu"))
        document.getElementById("contextMenu").remove();

        var contextMenu = document.createElement("div");
        contextMenu.classList.add("context-menu");
  
        var deleteOption = document.createElement("div");
        deleteOption.classList.add("menu-option");
        deleteOption.textContent = "حذف پیام";
  
        var copyOption = document.createElement("div");
        copyOption.classList.add("menu-option");
        copyOption.textContent = "کپی پیام";
  
  
        contextMenu.appendChild(deleteOption);
        contextMenu.appendChild(copyOption);

        contextMenu.id='contextMenu';
        contextMenu.style.position = "absolute";
        contextMenu.style.left = event.X + "px";
        contextMenu.style.top = event.Y + "px";
  
        chatBox.appendChild(contextMenu);*/
        
      });
    });
    document.addEventListener("click", function() {
      if(document.getElementById("contextMenu"))
            document.getElementById("contextMenu").remove();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Chall-Interview\resources\views/panel/chat.blade.php ENDPATH**/ ?>