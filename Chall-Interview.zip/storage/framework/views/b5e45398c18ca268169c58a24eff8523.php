
<?php $__env->startSection('style'); ?>
    <style>
        #content
        {
            color: #fff;
            background-image: url("<?php echo e(asset('img/home/back.png')); ?>");
            background-attachment: fixed;
            background-size: contain;
            background-repeat: repeat-y;
            /* background-repeat: no-repeat; */
            background-position: center;
            height: 100vh;
            /* height: 88vh; */
            padding: 4vw;
        }
       /* .home
        {
            background-image: url("<?php echo e(asset('img/home/mask.png')); ?>");
            background-size: cover;
            position: absolute;
            top: 0;
            left: 0;
            width: 50%;
            height: 100vh;
            opacity: 0.2;
            left: auto;
        }*/
        .card {
            background: linear-gradient(to right , #41467E, #23265B);
            border-radius: 30px;
            border: unset;
            /* box-shadow: -5px 0px 9px -3px #d2d3e38f; */
            color: #fff;
            padding: 10px;
            font-weight: bolder;
            font-family: 'PEYDA-BLACK';
            box-shadow: -5px 0px 9px -3px #d2d3e38f, 5px 5px 10px 0px #1c1e3c;
            margin-bottom: 30px;
        }
        .btn-master
        {
            background: linear-gradient(274deg, #1b1d50, #333870);
            border: 2px solid #5c6096;
            border-radius: 15px;
            color: #686da7;
            padding: 0px;
            width: 74px;
        }
                .logo
                {
                    height: 15vh;
                    width: 15vh;
                    box-shadow: 0 0 5px 1px #191b41; 
                }
                .circle
                {
                    width: 35px;
                    height: 35px;
                    border-radius: 50%;
                    background-color: #3e427a;
                    color: #fff;
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    font-size: 15px;
                    font-family: 'Vazir';

                }
                .status {
                border-radius: 50%;
                background-color: #23265b;
                
                display: flex;
                justify-content: center;
                align-items: center;
                font-size: 15px;   
                border: none;
                font-weight: bolder;
                width: 30px;
                height: 30px;
            }
            i.status.fa-close
            {                
                color: #ffa1a3;
            }
            i.status .fa-check
            {                
                color: #9effc2;
            }
            i.status .fa-exclamation
            {                
                color: #e9dd3d;
            }
    </style>
    <style>
         /* @media (max-width: 488px)
            { */
                
                .logo
                {
                    height: 17vh!important;
                    width: 100%!important;
                }
                .content-center
                {
                    width: 22vw!important;
                    margin: auto;
                }
                .card {
                   
                    padding: unset!important;
                font-size: 10pt!important;
                } 
                .btn-master {
                    width: 45px!important;
                    font-size: 8pt!important;
                    margin-left: 1px!important;
                    margin-top: 6px;
                }
        /* } */
        
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>   
<h6 class="mb-3 text-center" style="font-size: 14pt">چالش های امروز</h6> 
<div id="content2" class="content2">             
     <?php if($challs->count()): ?>
            <?php $__currentLoopData = $challs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <div class="card mt-2 p-md-3">
                <div class="card-body">
                    <div class="row d-flex">
                        <div class="col-1 m-auto" >                                
                                <span class="circle"><?php echo e($item->Chall->Level); ?></span>
                        </div>
                        <div class="col d-flex flex-column" >
                            <div class="p-0">
                                <?php if($item->Done): ?>
                                <i class="fa fa-check pull-left status" ></i>
                                <?php elseif($item->Expired): ?>
                                <i class="fa fa-exclamation pull-left status" ></i>
                                <?php else: ?>
                                <i class="fa fa-close pull-left status"></i>
                                <?php endif; ?>
                            </div>
                            <div class="d-flex flex-column mx-4">                                
                                <span style="font-size: 8pt;">
                                    <?php echo e($item->Chall->Title); ?>

                                </span>
                                <span style="font-size: 5pt;font-weight: normal;">
                                    <?php echo e(Str::limit($item->Chall->Body, 53, '...')); ?>

                                </span>
                            </div> 
                            <div class="p-0">
                                <button class="btn-master fa fa-arrow-left-long p-1 pull-left" onclick="location.href='<?php echo e(route('chall.details',[$item->Id])); ?>'">
                                
                                </button>
                            </div>
                        </div>                  
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
    <?php else: ?>
        <p class="text-center alert bg-2F3068">چالشی یافت نشد</p>
    <?php endif; ?>
</div>
<?php echo $__env->make('layouts.menu2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Chall-Interview\resources\views/panel/home.blade.php ENDPATH**/ ?>