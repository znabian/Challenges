
<div class="trophy_Active  <?php if(\Route::currentRouteName()!="home"): ?> d-none <?php endif; ?> "  >
    <i class="fa fa-trophy"></i>
</div>
<div class="history_Active  <?php if(\Route::currentRouteName()!="history"): ?> d-none <?php endif; ?> " >
    <i class="fa fa-history"></i>
</div>

<div class="commenting_Active <?php if(\Route::currentRouteName()!="chat.index"): ?> d-none <?php endif; ?> " >
    <i class="fa fa-commenting fa-regular"></i>
</div>

<div class="menu2 d-flex">
 
  <div class="d-grid c-pointer" onclick="location.href='<?php echo e(route('history')); ?>'">
    <?php if(\Route::currentRouteName()!="history"): ?>
    <i class="fa fa-history"></i>
    <b>تاریخچه</b>
  <?php else: ?>
    <b class="Active">تاریخچه</b>
  <?php endif; ?>
  </div>
  <div class="d-grid c-pointer" onclick="location.href='<?php echo e(route('home')); ?>'">
  <?php if(\Route::currentRouteName()!="home"): ?>
    <i class="fa fa-trophy"></i>
    <b>چالش</b>
  <?php else: ?>
    <b class="Active">چالش</b>
  <?php endif; ?>
  </div>
 
  <div class="d-grid c-pointer" onclick="logout()">    
      <i class="fa fa-sign-out"></i>
      <b>خروج</b>
  </div>
  </div>   
       <?php /**PATH C:\xampp\htdocs\Chall-Interview\resources\views/layouts/menu2.blade.php ENDPATH**/ ?>