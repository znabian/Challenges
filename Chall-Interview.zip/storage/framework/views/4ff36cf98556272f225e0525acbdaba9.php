<nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">سامانه رشد خوش نظر</a>
      <img src="<?php echo e(asset('img/logo.png')); ?>" alt="" style="width:50px;">
      
    </div>
  </nav><?php /**PATH C:\xampp\htdocs\Chall-Interview\resources\views/layouts/header.blade.php ENDPATH**/ ?>