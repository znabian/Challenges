  <nav class="p-2" style="/*column-gap: 20vw;*/height: 14vh;">
   
    <a class="pull-rigth  <?php if(\Route::currentRouteName()=="chall.details"): ?> d-none <?php endif; ?> " href="<?php echo e(route('home')); ?>" id="home">
      <img src="<?php echo e(asset('img/home/logo.png')); ?>" alt="Logo" class="navimg ">
    </a>
     <a class="pull-left  <?php if(\Route::currentRouteName()=="chall.details"): ?> d-none <?php endif; ?> " href="<?php echo e(route('notif.index')); ?>" >
      <i class="fa fa-circle dotnotif d-none" id="notif"></i>
      <img src="<?php echo e(asset('img/home/notif.png')); ?>" alt="Logo" class="navimg ">
    </a>

  </nav><?php /**PATH C:\xampp\htdocs\Chall-Interview\resources\views/layouts/menu.blade.php ENDPATH**/ ?>